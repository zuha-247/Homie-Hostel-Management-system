<?php
session_start();
include("connect.php");

// Handle form submission
$success = false;
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['Name'], $_POST['email'], $_POST['phone'])) {
    $name = htmlspecialchars($_POST["Name"]);
    $email = htmlspecialchars($_POST["email"]);
    $phone = htmlspecialchars($_POST["phone"]);
    $message = htmlspecialchars($_POST["Message"]);

    // Write message to messages.txt
    $file = 'messages.txt';
    $entry = "Name: $name\nEmail: $email\nPhone: $phone\nMessage: $message\n---\n";

    if (file_put_contents($file, $entry, FILE_APPEND | LOCK_EX) !== false) {
        $success = true;
    } else {
        echo "<p style='color:red;'>❌ Failed to write to messages.txt</p>";
    }
}
?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE-edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="homies.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.css" integrity="sha512-UTNP5BXLIptsaj5WdKFrkFov94lDx+eBvbKyoe1YAfjeRPC+gT5kyZ10kOHCfNZqEui1sxmqvodNUx3KbuYI/A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css" integrity="sha512-sMXtMNL1zRzolHYKEujM2AqCLUR9F2C4/05cdbxjjLSRvMQIciEPCQZo++nk7go3BtSuK9kfa/s+a4f4i5pLkw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha256-ZosEbRLbNQzLpnKIkEdrPv7lOy9C27hHQ+Xp8a4MxAQ=" crossorigin="anonymous"></script>
    <title>HOMIES website</title>
</head>
<body>
    <!--this is page 1 is about Home -->
    <div id="header">
        <div class="container">
            <nav>
                <img src="logo.jpeg" class="logo">
                <ul id="menulist">
                    <li><a href="#Home">Home</a></li>
                    <li><a href="#Room Booking">Room Booking</a></li>
                    <li><a href="#Services">Services</a></li>
                    <li><a href="#Gallery">Gallery</a></li>
                    <li><a href="#Fee Challan">Charges</a></li>
                    <li><a href="#about">About Us</a></li>
                    <li><a href="#Contact">Contact Us</a></li>
                </ul>

                <div class="nav-right">
                    <a href="#booknow" class="primary-btn"> BOOK NOW 📌</a>
                </div>
            </nav>

            <div class="content">
                <!-- Image on the Left -->
                <div class="left">
                    <img src="hostel1.jpeg" alt="">
                </div>

                <!-- Text on the Right -->
                <div class="right">
                    <div class="header-text">
                        <h1>Hello there!<br> Welcome to <span>HOMIES 🏠</span></h1>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <section id="Home" class="Home">

        <div class="content">
            <div class="owl-carousel owl-theme">
                <div class="item">
                    <img src="building.jpg" alt="">
                    <div class="text">
                        <h1>Make Your Memories with HOMIE</h1>
                        <p>A place that will make you feel that you are at your own place.</p>
                    </div>
                    <div class="flex">
                        <a href="javascript:void(0);" class="primary-btn" onclick="openReadMoreModal()">Read More 📖</a>
                        <a href="#Contactus-section" class="secondary-btn">CONTACT US ☎️</a>
                    </div>
                </div>
                <div class="item">
                    <img src="building1.jpg" alt="">
                    <div class="text">
                        <h1>Enjoy the essence of HOMIE</h1>
                        <p>A worthwhile experience one must take.</p>
                    </div>
                    <div class="flex">
                        <a href="javascript:void(0);" class="primary-btn" onclick="openReadMoreModal()">Read More 📖</a>
                        <a href="#Contactus-section" class="secondary-btn">CONTACT US ☎️</a>
                    </div>
                </div>
                <div class="item">
                    <img src="building3.jpg" alt="">
                    <div class="text">
                        <h1>Enjoy our services heartily!</h1>
                        <p>Our Customers stay our top priority.</p>
                    </div>
                    <div class="flex">
                        <a href="javascript:void(0);" class="primary-btn" onclick="openReadMoreModal()">Read More 📖</a>
                        <a href="#Contactus-section" class="secondary-btn">CONTACT US ☎️</a>
                    </div>
                </div>
            </div>
        </div>

    </section>

    <div id="readMoreModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeReadMoreModal()">&times;</span>
            <h2>Why Choose HOMIE?</h2>
            <p><strong>HOMIE</strong> stands out because it’s more than just a hostel—it’s your second home. We blend comfort, safety, and community spirit to give hostellites a place where they truly belong.</p>
            <p>Our 24/7 support staff, clean environment, secure premises, and community-building activities make us the most trusted and loved hostel option. Whether you're studying or relaxing, HOMIE makes you feel at home.</p>
            <h3>Our Staff</h3>
            <p>Our dedicated and friendly staff ensures a clean, safe, and welcoming environment...</p>
            <h3>Hostelite Ratings</h3>
            <ul>
                <li>Cleanliness: ⭐⭐⭐⭐☆ (4.5/5)</li>
                <li>Food Quality: ⭐⭐⭐⭐☆ (4.3/5)</li>
                <li>Staff Support: ⭐⭐⭐⭐⭐ (4.8/5)</li>
                <li>Facilities: ⭐⭐⭐⭐☆ (4.6/5)</li>
            </ul>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" integrity="sha512-bPs7Ae6pVvhOSiIcyUClR7/q2OAsRiovw4vAkX+zJbw3ShAeeqezq50RIIcIURq7Oa20rW2n2q+fyXBNcU9lrw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.js" integrity="sha512-gY25nC63ddE0LcLPhxUJGFxa2GoIyA5FLym4UJqHDEMHjp8RET6Zn/SHo1sltt3WuVtqfyxECP38/daUc/WVEA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script>
        $('.owl-carousel').owlCarousel({
            loop: true,
            margin: 0,
            nav: true,
            dots: false,
            navText: ["<i class=' fa fa-chevron-left'></i>", "<i class=' fa fa-chevron-right'></i>"],
            responsive: {
                0: {
                    items: 1
                },
                768: {
                    items: 1
                },
                1000: {
                    items: 1
                }
            }
        })

    </script>

    <!--this is page is about Book NOW-->

    <section id="booknow" class="booknow">
        <div class="container flex_space">
            <div class="text">
                <h1> <span>Book </span> Your Rooms</h1>
            </div>
            <div class="form">
                <form id="availability-form" class="form-grid">
                    <div class="form-row">
                        <label>Arrival Date  🗓️</label>
                        <input type="date" />
                    </div>
                    <div class="form-row">
                        <label>Departure Date 📆</label>
                        <input type="date" />
                    </div>
                    <div class="form-row">
                        <label>Room Number 🔢</label>
                        <input type="number" />
                    </div>
                    <div class="form-row services-row">
                        <label>Choose Services 🎁</label>
                        <div class="services-options">
                            <label><input type="checkbox" name="services" value="Food" />Food🍽️</label>
                            <label><input type="checkbox" name="services" value="Electricity" />Electricity⚡</label>
                            <label><input type="checkbox" name="services" value="Transport" />Transport🚌</label>
                            <label><input type="checkbox" name="services" value="Security" />Security🛡️</label>
                            <label><input type="checkbox" name="services" value="Internet" />Internet 🌐</label>
                        </div>
                    </div>
                    <input type="submit" value="CHECK AVAILABILITY 📅" />
                </form>
                <div id="availability-message" class="hidden-box">
                    ✅ The Room is available, Your Booking is accepted, Now select the room type in Room Booking Section 🙂
                </div>

            </div>
        </div>

    </section>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const form = document.getElementById("availability-form");
            const msgBox = document.getElementById("availability-message");

            form.addEventListener("submit", function (event) {
                event.preventDefault();

                // Get selected services
                const selectedServices = Array.from(document.querySelectorAll('input[name="services"]:checked'))
                    .map(cb => cb.value);

                // Display message
                msgBox.innerHTML = `✅ The Room is available, Your Booking is accepted, Now select the room type in Room Booking Section 🙂<br><br>
                                                            <strong>Selected Services:</strong> ${selectedServices.length > 0 ? selectedServices.join(', ') : 'None'}`;

                msgBox.classList.remove("hidden-box");
                msgBox.classList.add("visible-box");
            });

            // Hide box when user clicks outside of form or message
            document.addEventListener("click", function (event) {
                if (!msgBox.contains(event.target) && !form.contains(event.target)) {
                    msgBox.classList.remove("visible-box");
                    msgBox.classList.add("hidden-box");
                }
            });
        });
    </script>



    <section class="about top">
        <div class="container flex">
            <div class="left">
                <div class="heading">
                    <h1>WELCOME</h1>
                    <h2>HOMIE Hostel 😊</h2>
                </div>
                <p>Homies provide many services for our hostelites where they can feel a home in different place as their own without taking any tension.</p>
                <!-- About Us button links to section below -->
                <a href="#aboutus-section" class="primary-btn">ABOUT US ℹ️</a>
            </div>
            <div class="right">
                <img src="about.jpg" alt="">
            </div>
        </div>
    </section>


    <!------------------------- COUNTER ---------------->
    <section class="counter top">
        <div class="container grid">
            <div class="box">
                <h1>2500</h1>
                <hr>
                <span>Homies</span>
            </div>
            <div class="box">
                <h1>1250</h1>
                <hr>
                <span>Happy Homies</span>
            </div>
            <div class="box">
                <h1>250</h1>
                <hr>
                <span>Employees</span>
            </div>
        </div>
    </section>
    <!---------- ROOMS ------------------>
    <section class="RoomBooking">
        <div id="Room Booking">
            <div class="container top">
                <div class="heading">
                    <h1>EXPLORE</h1>
                    <h2>OUR ROOMS</h2>
                    <p>The comfiest Room for our HOMIES where they can sleep and live happily!</p>
                </div>
            </div>
            <!------------------------------------------------------ROOM 1-->
            <div class="content mtop">
                <div class="owl-carousel owl-carousel1 owl-theme">
                    <div class="items">
                        <div class="image">
                            <img src="bed_one.jpg" alt="">
                        </div>
                        <div class="text">
                            <h2>Bed For One</h2>
                            <div class="rate flex">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </div>
                            <p> A separate sanctuary for you to completely feel at home</p>
                            <div class="button flex">
                                <button class="primary-btn">BOOK NOW</button>
                                <h3>Rs 20,000</h3>
                            </div>
                        </div>
                    </div>
                    <div class="items">
                        <div class="image">
                            <img src="bed_three.jpg" alt="">
                        </div>
                        <div class="text">
                            <h2>Bed For Three</h2>
                            <div class="rate flex">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </div>
                            <p> Three buddies can stay together with their own beds and share and make memories together.</p>
                            <div class="button flex">
                                <button class="primary-btn">BOOK NOW</button>
                                <h3>Rs 15,000</h3>
                            </div>
                        </div>
                    </div>
                    <div class="items">
                        <div class="image">
                            <img src="bed_four.jpg" alt="">
                        </div>
                        <div class="text">
                            <h2>Bed For Four</h2>
                            <div class="rate flex">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </div>
                            <p> Share your place with others and enjoy your time at Homies.</p>
                            <div class="button flex">
                                <button class="primary-btn">BOOK NOW</button>
                                <h3>Rs 12,000</h3>
                            </div>
                        </div>
                    </div>
                    <div class="items">
                        <div class="image">
                            <img src="bed_2.jpg" alt="">
                        </div>
                        <div class="text">
                            <h2>Bed For Two</h2>
                            <div class="rate flex">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </div>
                            <p> Two friends under one roof.The perfect match.</p>
                            <div class="button flex">
                                <button class="primary-btn">BOOK NOW</button>
                                <h3>Rs 18,000</h3>
                            </div>
                        </div>
                    </div>
                    <div class="items">
                        <div class="image">
                            <img src="bed_multiple.jpg" alt="">
                        </div>
                        <div class="text">
                            <h2>Bed For Mutiple People</h2>
                            <div class="rate flex">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </div>
                            <p> Customize the number of roomates you want according to your choice.(From 2 to 7)</p>
                            <div class="button flex">
                                <button class="primary-btn">BOOK NOW</button>
                                <h3>10,000 Rs</h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div id="booking-message" class="hidden-box">
            ✅ Room successfully booked!
        </div>

    </section>
    <script>
        $('.owl-carousel').owlCarousel({
            loop: true,
            margin: 40,
            nav: true,
            dots: false,
            navText: ["<i class=' fa fa-chevron-left'></i>", "<i class=' fa fa-chevron-right'></i>"],
            responsive: {
                0: {
                    items: 1
                },
                768: {
                    items: 2,
                    margin: 10,
                },
                1000: {
                    items: 3
                }
            }
        })
    </script>

    <script>
        document.querySelectorAll(".RoomBooking .primary-btn").forEach((btn) => {
            btn.addEventListener("click", function (event) {
                event.stopPropagation(); // Prevent outside-click event from triggering immediately

                const card = btn.closest(".items");
                const roomType = card.querySelector("h2").innerText;
                const price = card.querySelector("h3").innerText;

                const arrival = document.querySelectorAll('input[type="date"]')[0]?.value || "Not Provided";
                const departure = document.querySelectorAll('input[type="date"]')[1]?.value || "Not Provided";

                const selectedServices = Array.from(document.querySelectorAll('input[name="services"]:checked'))
                    .map(cb => cb.value).join(', ') || "None";

                // ✅ Remove any existing message box first
                const existingBox = document.getElementById("custom-booking-box");
                if (existingBox) existingBox.remove();

                // ✅ Create new success box
                const bookingBox = document.createElement("div");
                bookingBox.id = "custom-booking-box";
                bookingBox.innerHTML = `
                                                        ✅ Room "<strong>${roomType}</strong>" booked successfully!<br>
                                                        <strong>Price:</strong> ${price}<br>
                                                        <strong>Arrival:</strong> ${arrival}<br>
                                                        <strong>Departure:</strong> ${departure}<br>
                                                        <strong>Services:</strong> ${selectedServices}
                                                    `;
                bookingBox.classList.add("booking-popup");
                document.body.appendChild(bookingBox);

                // ✅ Send data to Google Sheets
                fetch("https://script.google.com/macros/s/AKfycbxjit6bEI7fMEPMNM_RD9L7rqqrrtCddnNpdsv-pBHEULDGK83ln7065hucjUjTBedd/exec", {
                    method: "POST",
                    body: JSON.stringify({
                        roomType,
                        price,
                        arrival,
                        departure,
                        services: selectedServices
                    }),
                    headers: { "Content-Type": "application/json" }
                });

                // ✅ Auto-remove after 5 seconds
                setTimeout(() => {
                    bookingBox.remove();
                }, 5000);

                // ✅ Remove on outside click
                document.addEventListener("click", function hideBox(e) {
                    if (!bookingBox.contains(e.target)) {
                        bookingBox.remove();
                        document.removeEventListener("click", hideBox);
                    }
                });
            });
        });
    </script>



    <!--------------------------- services and Gallery ------------------------>
    <section class="gallery">
        <div id="Gallery">
            <div class="container top">
                <div class="heading">
                    <h1>PHOTOS</h1>
                    <h2>OUR SERVICES</h2>
                </div>
            </div>

            <div class="content mtop">
                <div class="owl-carousel owl-carousel1 owl-theme">
                    <div class="items">
                        <div class="img">
                            <img src="bed.jpg" alt="">
                        </div>
                        <div class="overlay">
                            <h3> A room with imbundance of sunlight.</h3>
                        </div>
                    </div>
                    <div class="items">
                        <div class="img">
                            <img src="mess.jpg" alt="">
                        </div>
                        <div class="overlay">
                            <h3> A joint place for you to eat.</h3>
                        </div>
                    </div>
                    <div class="items">
                        <div class="img">
                            <img src="transport.jpg" alt="">
                        </div>
                        <div class="overlay">
                            <h3> Fast Transport Service.</h3>
                        </div>
                    </div>
                    <div class="items">
                        <div class="img">
                            <img src="security.jpg" alt="">
                        </div>
                        <div class="overlay">
                            <h3> Providing you with security 24/7.</h3>
                        </div>
                    </div>
                    <div class="items">
                        <div class="img">
                            <img src="livingroom.jpg" alt="">
                        </div>
                        <div class="overlay">
                            <h3> A living space for our clients to enjoy.</h3>
                        </div>
                    </div>
                    <div class="items">
                        <div class="img">
                            <img src="internet.jpg" alt="">
                        </div>
                        <div class="overlay">
                            <h3> Internet Services.</h3>
                        </div>
                    </div>
                </div>
            </div>
    </section>
    <script>
        $('.owl-carousel').owlCarousel({
            loop: true,
            margin: 0,
            nav: true,
            dots: false,
            autoplay: true,
            autoplayTimeout: 1000,
            autoplayHoverPause: true,
            navText: ["<i class=' fa fa-chevron-left'></i>", "<i class=' fa fa-chevron-right'></i>"],
            responsive: {
                0: {
                    items: 1
                },
                768: {
                    items: 4,
                },
                1000: {
                    items: 6
                }
            }
        })
    </script>

    <section class="services">
        <div id="Services">
            <div class="container">
                <div class="heading">
                    <h1>SERVICES</h1>
                    <h2>What we Provide?</h2>
                </div>

                <div class="content flex_space">
                    <div class="left grid2">
                        <div class="box">
                            <div class="text">
                                <i class="fa-solid fa-utensils"></i>
                                <h3>Delicious Food </h3>
                                <p style="color: purple;">Food just like the home one</p>


                            </div>
                        </div>
                        <div class="box">
                            <div class="text">
                                <i class="fa-solid fa-shield"></i>
                                <h3>Security Service </h3>
                                <p style="color: purple;">Every Homie is our responsibility, so security is important for everyone</p>


                            </div>
                        </div>
                        <div class="box">
                            <div class="text">
                                <i class="fa-solid fa-wifi"></i>
                                <h3>Internet Service </h3>
                                <p style="color: purple;">Internet package for every Homie</p>


                            </div>
                        </div>
                        <div class="box">
                            <div class="text">
                                <i class="fa-solid fa-bus"></i>
                                <h3>Transport Service </h3>
                                <p style="color: purple;">Homie can go wherever they want</p>


                            </div>
                        </div>
                        <div class="box">
                            <div class="text">
                                <i class="fas fa-gamepad"></i>
                                <h3> Game Area </h3>
                                <p style="color: purple;">Homie can play games and relieve stress</p>


                            </div>
                        </div>
                        <div class="box">
                            <div class="text">
                                <i class="fa-solid fa-ellipsis-h"></i>
                                <h3>Other Service</h3>
                                <p style="color: purple;">(A/C, Heater, Iron Clothes, etc.)</p>


                            </div>
                        </div>
                    </div>
                </div>


            </div>
        </div>
    </section>
    <!---------------------------Fee Challan------------------------>
    <section class="fee">
        <div id="Fee Challan">
            <div class="container">
                <!-- Left Column -->
                <div class="column">
                    <h1>CHARGES</h1>

                    <div class="box">
                        <h2>Fee of Services</h2>
                        <p>Homies provide many services for our hostelites where they can feel at home without any worries.</p>
                    </div>

                    <div class="box">
                        <h2>Food Service</h2>
                        <p>A home that provides unforgettable food. <br>Fee: 1500 Rs</p>
                    </div>

                    <div class="box">
                        <h2>Security</h2>
                        <p>Security and privacy for every homie.<br>Fee: 3000 Rs</p>
                    </div>
                </div>

                <!-- Right Column -->
                <div class="column">
                    <div class="box">
                        <h2>Internet Service</h2>
                        <p>Unlimited internet access for every homie.<br>Fee: 5000 Rs</p>
                    </div>

                    <div class="box">
                        <h2>Transport</h2>
                        <p>Transport services for work and studies.<br>Fee: 8000 Rs</p>
                    </div>

                    <div class="box">
                        <h2>Electricity</h2>
                        <p>Ironing, A/C, heaters, and more.<br>Fee: 6000 Rs</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="box total-box">
            <h2>Total Bill</h2>
            <p id="totalBill">Click "See Bill" to view your total.</p>
        </div>

        <!-- Add a button to trigger bill calculation -->
        <div style="text-align: center; margin-top: 20px;">
            <button id="seeBillBtn">See Bill</button>
        </div>
    </section>

    <script>
        // Service prices
        const servicePrices = {
            'Food': 1500,
            'Security': 3000,
            'Internet': 5000,
            'Transport': 8000,
            'Electricity': 6000
        };

        // Global selected room
        let selectedRoom = {
            type: null,
            price: 0
        };

        const seeBillBtn = document.getElementById('seeBillBtn');
        const totalBillElement = document.getElementById('totalBill');
        const totalBox = document.querySelector(".total-box");

        // Room booking buttons
        document.querySelectorAll(".RoomBooking .primary-btn").forEach((btn) => {
            btn.addEventListener("click", function (event) {
                event.stopPropagation();

                const card = btn.closest(".items");
                const roomType = card.querySelector("h2").innerText;
                const priceText = card.querySelector("h3").innerText;
                const price = parseInt(priceText.replace(/[^\d]/g, ''));

                // Save selected room
                selectedRoom.type = roomType;
                selectedRoom.price = price;

                const arrival = document.querySelectorAll('input[type="date"]')[0]?.value || "Not Provided";
                const departure = document.querySelectorAll('input[type="date"]')[1]?.value || "Not Provided";

                const selectedServices = Array.from(document.querySelectorAll('input[name="services"]:checked'))
                    .map(cb => cb.value).join(', ') || "None";

                // Show booking box
                const existingBox = document.getElementById("custom-booking-box");
                if (existingBox) existingBox.remove();

                const bookingBox = document.createElement("div");
                bookingBox.id = "custom-booking-box";
                bookingBox.innerHTML = `
                                        ✅ Room "<strong>${roomType}</strong>" booked successfully!<br>
                                        <strong>Price:</strong> ${price} Rs<br>
                                        <strong>Arrival:</strong> ${arrival}<br>
                                        <strong>Departure:</strong> ${departure}<br>
                                        <strong>Services:</strong> ${selectedServices}
                                    `;
                bookingBox.classList.add("booking-popup");
                document.body.appendChild(bookingBox);

                // Optional: Send to Google Sheets
                fetch("https://script.google.com/macros/s/AKfycbxjit6bEI7fMEPMNM_RD9L7rqqrrtCddnNpdsv-pBHEULDGK83ln7065hucjUjTBedd/exec", {
                    method: "POST",
                    body: JSON.stringify({
                        roomType,
                        price,
                        arrival,
                        departure,
                        services: selectedServices
                    }),
                    headers: { "Content-Type": "application/json" }
                });

                setTimeout(() => bookingBox.remove(), 5000);
                document.addEventListener("click", function hideBox(e) {
                    if (!bookingBox.contains(e.target)) {
                        bookingBox.remove();
                        document.removeEventListener("click", hideBox);
                    }
                });
            });
        });

        // Generate final bill
        seeBillBtn.addEventListener('click', function (e) {
            e.stopPropagation();

            let total = 0;
            let billHTML = "<h3>🧾 Your Bill Details:</h3>";

            // Add room info
            if (selectedRoom.type) {
                billHTML += `<p><strong>Room Type:</strong> ${selectedRoom.type} - Rs ${selectedRoom.price}</p>`;
                total += selectedRoom.price;
            } else {
                billHTML += `<p><strong>Room:</strong> ❌ Not selected</p>`;
            }

            // Add services
            const selectedServices = [];
            document.querySelectorAll('input[name="services"]:checked').forEach(cb => {
                const service = cb.value;
                if (servicePrices[service]) {
                    selectedServices.push({ name: service, price: servicePrices[service] });
                    total += servicePrices[service];
                }
            });

            if (selectedServices.length > 0) {
                billHTML += "<p><strong>Services Selected:</strong></p><ul>";
                selectedServices.forEach(service => {
                    billHTML += `<li>${service.name} - Rs ${service.price}</li>`;
                });
                billHTML += "</ul>";
            } else {
                billHTML += "<p><strong>Services:</strong> None selected</p>";
            }

            // Total
            billHTML += `<h4>💰 <strong>Total Bill:</strong> Rs ${total}</h4>`;

            // Show the bill
            totalBox.style.display = "block";
            totalBillElement.innerHTML = billHTML;
        });

        // Hide bill box on outside click
        document.addEventListener('click', function () {
            totalBox.style.display = "none";
        });

        totalBox.addEventListener('click', function (e) {
            e.stopPropagation(); // Don't hide if clicked inside
        });
    </script>


    <!-----------       ABOUT US      ------------>
    <section class="aboutus" id="aboutus-section">

        <div id="about">
            <div class="container">
                <div class="heading">
                    <h1>ABOUT US</h1>
                    <h2>What we Do?</h2>
                </div>
                <div class="work-list">
                    <div class="work">
                        <img src="person.jpg" alt="">
                        <div class="layer">
                            <h3>Areeba Akmal</h3>
                            <p>
                                Group Leader, The Designer.
                            </p>
                            <a href="javascript:void(0);" onclick="openModal('modal-areeba')"><i class="fa fa-external-link"></i></a>
                        </div>
                    </div>
                    <div class="work">
                        <img src="person.jpg" alt="">
                        <div class="layer">
                            <h3>Ayesha Noor</h3>
                            <p>
                                The Architect.
                            </p>
                            <a href="javascript:void(0);" onclick="openModal('modal-ayesha')"><i class="fa fa-external-link"></i></a>
                        </div>
                    </div>
                    <div class="work">
                        <img src="person.jpg" alt="">
                        <div class="layer">
                            <h3>Zuha Qayyum</h3>
                            <p>
                                The Developer.
                            </p>
                            <a href="javascript:void(0);" onclick="openModal('modal-zuha')"><i class="fa fa-external-link"></i></a>
                        </div>
                    </div>
                </div>
                <a href="#" class="btn" onclick="openAboutModal()">See More 👀</a>
            </div>
        </div>

    </section>

    <!-- Modals (place outside the aboutus section) -->
    <div id="modal-areeba" class="member-modal">
        <div class="member-modal-content">
            <span class="member-modal-close" onclick="closeModal('modal-areeba')">&times;</span>
            <h2>Areeba Akmal - Group Leader & The Designer 👩🏻‍🎨</h2>
            <p>With a keen eye for aesthetics and a mind built for leadership, Areeba transforms ideas into stunning visual realities. Her creativity fuels the design, and her direction powers the entire team forward. She's not just a designer—she's the visionary behind the experience.</p>
        </div>
    </div>

    <div id="modal-ayesha" class="member-modal">
        <div class="member-modal-content">
            <span class="member-modal-close" onclick="closeModal('modal-ayesha')">&times;</span>
            <h2>Ayesha Noor - The Architect 👷‍♀️</h2>
            <p>Ayesha is the brain behind the blueprint. Structured, strategic, and always thinking ten steps ahead, she ensures that every element fits together seamlessly. Her logic-driven mindset turns chaos into clarity and plans into powerful outcomes.</p>
        </div>
    </div>

    <div id="modal-zuha" class="member-modal">
        <div class="member-modal-content">
            <span class="member-modal-close" onclick="closeModal('modal-zuha')">&times;</span>
            <h2>Zuha Qayyum - The Developer 👩🏻‍💻</h2>
            <p>Zuha is the one who brings ideas to life. With code as her canvas and innovation as her language, she builds powerful solutions that just work. Whether it's front-end beauty or back-end strength, Zuha delivers brilliance line by line.</p>
        </div>
    </div>

    <!-- About Modal -->
    <div id="aboutModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeAboutModal()">&times;</span>
            <h2>About HOMIE</h2>
            <p><strong>Homie</strong> is a hostel for hostellites that provides them with a homely environment, making sure they feel comfortable and supported during their stay.</p>
            <h3>⭐ Hostellite Rating HOMIE</h3>
            <p>Rated 4.9/5 by hostellites based on comfort, facilities, and community spirit!</p>
            <h3> HOMIE Staff</h3>
            <p>Our Staff is ver cooperative and works for 24/7, there are security guards, cleaner and chefs and they work professionaly giving no chnace of mistake that can be noticed by Homie 😊.</p>

            <h3>🌟 Meet Our Team</h3>
            <ul>
                <li><strong>Areeba Akmal</strong> – Visionary leader and the brain behind our design language.</li>
                <li><strong>Ayesha Noor</strong> – The architect of our structure, ensuring flawless execution.</li>
                <li><strong>Zuha Qayyum</strong> – Master coder who brings our ideas to digital life.</li>
            </ul>
        </div>
    </div>

    <script>
        var tablinks = document.querySelectorAll(".tab-links");
        var tabcontents = document.querySelectorAll(".tab-contents");

        function opentab(tabname) {
            for (var z = 0; z < tablinks.length; z++) {
                tablinks[z].classList.remove("active-link");
            }
            for (var z = 0; z < tabcontents.length; z++) {
                tabcontents[z].classList.remove("active-tab");
            }

            var selectedTab = document.getElementById(tabname);
            selectedTab.classList.add("active-tab");

            for (var z = 0; z < tablinks.length; z++) {
                if (tablinks[z].textContent.toLowerCase() == tabname) {
                    tablinks[z].classList.add("active-link");
                }
            }
        }

        function openModal(id) {
            document.getElementById(id).style.display = 'block';
        }

        function closeModal(id) {
            document.getElementById(id).style.display = 'none';
        }

        window.onclick = function (event) {
            const modals = document.querySelectorAll('.member-modal');
            modals.forEach(modal => {
                if (event.target === modal) {
                    modal.style.display = "none";
                }
            });
        }

        function openAboutModal() {
            document.getElementById("aboutModal").style.display = "block";
        }

        function closeAboutModal() {
            document.getElementById("aboutModal").style.display = "none";
        }

        function openReadMoreModal() {
            document.getElementById("readMoreModal").style.display = "block";
        }

        function closeReadMoreModal() {
            document.getElementById("readMoreModal").style.display = "none";
        }

        window.onclick = function (event) {
            const modals = document.querySelectorAll('.member-modal, #aboutModal, #readMoreModal');
            modals.forEach(modal => {
                if (event.target === modal) {
                    modal.style.display = "none";
                }
            });
        }
    </script>




    <!-------Contact-------->
    <section class="Contactus" id="Contactus-section">
        <div id="Contact">
            <div class="container">
                <div class="row">
                    <div class="contact-left">
                        <h1 class="sub-title">Contact Us</h1>
                        <p><i class="fa fa-send"></i> Homie@gmail.com</p>
                        <p><i class="fa fa-phone"></i> 0311654321</p>
                        <div class="social-icons">
                            <a href=""><i class="fa fa-facebook-square"></i></a>
                            <a href=""><i class="fa fa-twitter-square"></i></a>
                            <a href=""><i class="fa fa-instagram"></i></a>
                            <a href=""><i class="fa fa-linkedin-square"></i></a>
                        </div>
                    </div>

                    <div class="contact-right">
                        <!-- Contact Form -->
                        <form id="contact-form" method="POST" action="index.php">
                            <input type="text" name="Name" placeholder="Your Name" required>
                            <input type="email" name="email" placeholder="Your Email Address" required>
                            <input type="tel" name="phone" placeholder="Your Phone Number" required>
                            <textarea name="Message" rows="6" placeholder="Your Message/Complaint"></textarea>
                            <button type="submit" class="btn btn2">Send ⌯⌲</button>
                        </form>

                        <?php if ($success): ?>
                            <div id="message-box" class="visible-message">Your message has been successfully sent! 😊</div>
                        <?php else: ?>
                            <div id="message-box" class="hidden-message"></div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <div class="copyright">
        <p>Copyright @ Homies. Made with <i class="fa fa-heart" style="color: #bf00bf;"></i> by Ayesha, Zuha and Areeba</p>
    </div>

    <script>
        // Success message after form submission
        document.getElementById("contact-form").addEventListener("submit", function (event) {
            var msgBox = document.getElementById("message-box");
            if (msgBox) {
                msgBox.classList.remove("hidden-message");
                msgBox.classList.add("visible-message");
            }
        });
    </script>

</body>
</html>