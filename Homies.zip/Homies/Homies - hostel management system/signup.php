<?php 
include 'connect.php';

if (isset($_POST['signUp'])) {
	$firstName = isset($_POST['fName']) ? $_POST['fName'] : '';
	$lastname = isset($_POST['lName']) ? $_POST['lName'] : '';
	$email = isset($_POST['email']) ? $_POST['email'] : '';
	$password = isset($_POST['password']) ? $_POST['password'] : '';
	$password = md5($password);

	$checkEmail = "SELECT * FROM users WHERE email='$email'";
	$result = $conn->query($checkEmail);

	if ($result->num_rows > 0) {
		echo "Email Address Already Exists!";
	} else {
		$insertQuery = "INSERT INTO users(firstname, lastname, email, password)
		                VALUES ('$firstName', '$lastname', '$email', '$password')";
		if ($conn->query($insertQuery) === TRUE) {
			header("Location: login-signup.php");
		} else {
			echo "Error: " . $conn->error;
		}
	}
}



if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $password = md5($password);

    $sql = "SELECT * FROM users WHERE email='$email' and password='$password'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        session_start();
        $row = $result->fetch_assoc();
        $_SESSION['email'] = $row['email'];
        header("Location: index.php");
        exit();
    } else {
        echo "NOT FOUND, Incorrect Email or Password";
    }
}

?>